BRITISH_QUIZ = [
    {
        "question": "Which one of these is 'the woman'?",
        "options": [
            {"text": "the boy", "image": "quiz_images/boy.jpg"},
            {"text": "the woman", "image": "quiz_images/girl.png"},
            {"text": "the man", "image": "quiz_images/men.png"},
        ],
        "correct": "the woman"
    },
    {
        "question": "Which one is 'the man'?",
        "options": [
            {"text": "the woman", "image": "quiz_images/girl.png"},
            {"text": "the man", "image": "quiz_images/men.png"},
            {"text": "the boy", "image": "quiz_images/boy.jpg"},
        ],
        "correct": "the man"
    },
     {
        "question": "Which one of these is 'the boy'?",
        "options": [
            {"text": "the woman", "image": "quiz_images/girl.png"},
            {"text": "the man", "image": "quiz_images/men.png"},
            {"text": "the boy", "image": "quiz_images/boy.jpg"},
        ],
        "correct": "the boy"
    },
      {
        "question": "Which one of these is 'the Baby'?",
        "options": [
            {"text": "the monkey", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the apple", "image": "quiz_images/the_apple.jpg"},
            {"text": "the baby", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the baby"
    },
       {
        "question": "Which one of these is 'the Monkey'?",
        "options": [
            {"text": "the baby", "image": "quiz_images/baby.jpg"},
            {"text": "the monkey", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the apple", "image": "quiz_images/the_apple.jpg"},
        ],
        "correct": "the Monkey"
    },
        {
        "question": "Which one of these is 'the Apple'?",
        "options": [
            {"text": "the apple", "image": "quiz_images/the_apple.jpg"},
            {"text": "the monkey", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the baby", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the Apple"
    },
        
         {
        "question": "Which one of these is 'the Car'?",
        "options": [
            {"text": "the car", "image": "quiz_images/car.jpg"},
            {"text": "the football", "image": "quiz_images/football.jpg"},
            {"text": "the cycle", "image": "quiz_images/cycle.jpg"},
        ],
        "correct": "the Car"
    },
          {
        "question": "Which one of these is 'the Bike'?",
        "options": [
            {"text": "the bike", "image": "quiz_images/bike.jpg"},
            {"text": "the car", "image": "quiz_images/car.jpg"},
            {"text": "the football", "image": "quiz_images/football.jpg"},
        ],
        "correct": "the Bike"
    },
           {
        "question": "Which one of these is 'the Cycle'?",
        "options": [
            {"text": "the car", "image": "quiz_images/car.jpg"},
            {"text": "the bike", "image": "quiz_images/bike.jpg"},
            {"text": "the cycle", "image": "quiz_images/cycle.jpg"},
        ],
        "correct": "the Cycle"
    },
            {
        "question": "Which one of these is 'the Football'?",
        "options": [
            {"text": "the bike", "image": "quiz_images/bike.jpg"},
            {"text": "the football", "image": "quiz_images/football.jpg"},
            {"text": "the baby", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the Football"
    },
]
