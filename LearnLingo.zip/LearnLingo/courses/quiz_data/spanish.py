SPANISH_QUIZ = [
   
    {
        "question": "Which one of these is 'the woman'?",
        "options": [
            {"text": "the chico", "image": "quiz_images/boy.jpg"},
            {"text": "the mujer", "image": "quiz_images/girl.png"},
            {"text": "the hombre", "image": "quiz_images/men.png"},
        ],
        "correct": "the mujer"
    },
    {
        "question": "Which one is 'the man'?",
        "options": [
            {"text": "the mujer", "image": "quiz_images/girl.png"},
            {"text": "the hombre", "image": "quiz_images/men.png"},
            {"text": "the chico", "image": "quiz_images/boy.jpg"},
        ],
        "correct": "the hombre"
    },
     {
        "question": "Which one of these is 'the boy'?",
        "options": [
            {"text": "the mujer", "image": "quiz_images/girl.png"},
            {"text": "the hombre", "image": "quiz_images/men.png"},
            {"text": "the chico", "image": "quiz_images/boy.jpg"},
        ],
        "correct": "the chico"
    },
      {
        "question": "Which one of these is 'the Baby'?",
        "options": [
            {"text": "the mona", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the manzana", "image": "quiz_images/the_apple.jpg"},
            {"text": "the bebé", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the bebé"
    },
       {
        "question": "Which one of these is 'the Monkey'?",
        "options": [
            {"text": "the bebé", "image": "quiz_images/baby.jpg"},
            {"text": "the mona", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the manzana", "image": "quiz_images/the_apple.jpg"},
        ],
        "correct": "the mona"
    },
        {
        "question": "Which one of these is 'the Apple'?",
        "options": [
            {"text": "the manzana", "image": "quiz_images/the_apple.jpg"},
            {"text": "the mona", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the bebé", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the manzana"
    },
        
         {
        "question": "Which one of these is 'the Car'?",
        "options": [
            {"text": "the auto", "image": "quiz_images/car.jpg"},
            {"text": "the fútbol americano", "image": "quiz_images/football.jpg"},
            {"text": "the bicicleta", "image": "quiz_images/cycle.jpg"},
        ],
        "correct": "the auto"
    },
          {
        "question": "Which one of these is 'the Bike'?",
        "options": [
            {"text": "the moto", "image": "quiz_images/bike.jpg"},
            {"text": "the auto", "image": "quiz_images/car.jpg"},
            {"text": "the fútbol americano", "image": "quiz_images/football.jpg"},
        ],
        "correct": "the moto"
    },
           {
        "question": "Which one of these is 'the Cycle'?",
        "options": [
            {"text": "the auto", "image": "quiz_images/car.jpg"},
            {"text": "the moto", "image": "quiz_images/bike.jpg"},
            {"text": "the bicicleta", "image": "quiz_images/cycle.jpg"},
        ],
        "correct": "the bicicleta"
    },
            {
        "question": "Which one of these is 'the Football'?",
        "options": [
            {"text": "the moto", "image": "quiz_images/bike.jpg"},
            {"text": "the fútbol americano", "image": "quiz_images/football.jpg"},
            {"text": "the bebé", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the fútbol americano"
    },
]


