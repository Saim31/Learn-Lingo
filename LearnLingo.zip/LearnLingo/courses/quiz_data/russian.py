RUSSIAN_QUIZ = [
   
    {
        "question": "Which one of these is 'the woman'?",
        "options": [
            {"text": "the mal'chik", "image": "quiz_images/boy.jpg"},
            {"text": "the zhenshchiny", "image": "quiz_images/girl.png"},
            {"text": "the muzhchina", "image": "quiz_images/men.png"},
        ],
        "correct": "the zhenshchiny"
    },
    {
        "question": "Which one is 'the man'?",
        "options": [
            {"text": "the zhenshchiny", "image": "quiz_images/girl.png"},
            {"text": "the muzhchina", "image": "quiz_images/men.png"},
            {"text": "the mal'chik", "image": "quiz_images/boy.jpg"},
        ],
        "correct": "the muzhchina"
    },
     {
        "question": "Which one of these is 'the boy'?",
        "options": [
            {"text": "the zhenshchiny", "image": "quiz_images/girl.png"},
            {"text": "the muzhchina", "image": "quiz_images/men.png"},
            {"text": "the mal'chik", "image": "quiz_images/boy.jpg"},
        ],
        "correct": "the mal'chik"
    },
      {
        "question": "Which one of these is 'the Baby'?",
        "options": [
            {"text": "the obez'yana", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the yabloko", "image": "quiz_images/the_apple.jpg"},
            {"text": "the malysh", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the malysh"
    },
       {
        "question": "Which one of these is 'the Monkey'?",
        "options": [
            {"text": "the malysh", "image": "quiz_images/baby.jpg"},
            {"text": "the obez'yana", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the yabloko", "image": "quiz_images/the_apple.jpg"},
        ],
        "correct": "the obez'yana"
    },
        {
        "question": "Which one of these is 'the Apple'?",
        "options": [
            {"text": "the yabloko", "image": "quiz_images/the_apple.jpg"},
            {"text": "the obez'yana", "image": "quiz_images/the_monkey.jpg"},
            {"text": "the malysh", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the yabloko"
    },
        
         {
        "question": "Which one of these is 'the Car'?",
        "options": [
            {"text": "the mashina", "image": "quiz_images/car.jpg"},
            {"text": "the futbol", "image": "quiz_images/football.jpg"},
            {"text": "the velosiped", "image": "quiz_images/cycle.jpg"},
        ],
        "correct": "the mashina"
    },
          {
        "question": "Which one of these is 'the Bike'?",
        "options": [
            {"text": "the mototsikl", "image": "quiz_images/bike.jpg"},
            {"text": "the mashina", "image": "quiz_images/car.jpg"},
            {"text": "the futbol", "image": "quiz_images/football.jpg"},
        ],
        "correct": "the mototsikl"
    },
           {
        "question": "Which one of these is 'the Cycle'?",
        "options": [
            {"text": "the mashina", "image": "quiz_images/car.jpg"},
            {"text": "the mototsikl", "image": "quiz_images/bike.jpg"},
            {"text": "the velosiped", "image": "quiz_images/cycle.jpg"},
        ],
        "correct": "the velosiped"
    },
            {
        "question": "Which one of these is 'the Football'?",
        "options": [
            {"text": "the mototsikl", "image": "quiz_images/bike.jpg"},
            {"text": "the futbol", "image": "quiz_images/football.jpg"},
            {"text": "the malysh", "image": "quiz_images/baby.jpg"},
        ],
        "correct": "the futbol"
    },
]
