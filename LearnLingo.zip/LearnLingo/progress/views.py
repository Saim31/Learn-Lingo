from django.shortcuts import render

def dashboard(request):
    return render(request, 'progress/dashboard.html')
